# Fashioo-Live

Fashioo's second generation prototype website

[![Netlify Status](https://api.netlify.com/api/v1/badges/21ec9535-08af-43ac-9d7a-617329e15eb9/deploy-status)](https://app.netlify.com/sites/fashioo/deploys)
